#!/usr/bin/env node

/**
 * aivon-zalo — Zalo CLI and MCP server used by Aivon (multi-account, proxy).
 * Entry point: registers all command groups via Commander.js.
 */

import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { Command } from "commander";
import { registerLoginCommands } from "./commands/login.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const pkg = JSON.parse(readFileSync(join(__dirname, "..", "package.json"), "utf8"));
import { registerMsgCommands } from "./commands/msg.js";
import { registerFriendCommands } from "./commands/friend.js";
import { registerGroupCommands } from "./commands/group.js";
import { registerConvCommands } from "./commands/conv.js";
import { registerAccountCommands } from "./commands/account.js";
import { registerProfileCommands } from "./commands/profile.js";
import { registerPollCommands } from "./commands/poll.js";
import { registerReminderCommands } from "./commands/reminder.js";
import { registerAutoReplyCommands } from "./commands/auto-reply.js";
import { registerQuickMsgCommands } from "./commands/quick-msg.js";
import { registerLabelCommands } from "./commands/label.js";
import { registerCatalogCommands } from "./commands/catalog.js";
import { registerListenCommand } from "./commands/listen.js";
import { registerOACommands } from "./commands/oa.js";
import { registerMCPCommands } from "./commands/mcp.js";
import { autoLogin } from "./core/zalo-client.js";
import { warning } from "./utils/output.js";

const DISCLAIMER =
    "This tool uses unofficial Zalo APIs (zca-js) — your account may be banned. Use at your own risk. | Tool này dùng API Zalo không chính thức (zca-js) — account có thể bị ban. Tự chịu trách nhiệm.";

const program = new Command();

program
    .name("aivon-zalo")
    .description("CLI tool for Zalo automation — multi-account, proxy, bank transfers, QR payments")
    .version(pkg.version)
    .option("--json", "Output results as JSON (machine-readable)")
    .hook("preAction", async (thisCommand) => {
        const cmdName = thisCommand.args?.[0] || thisCommand.name();
        // Suppress zca-js internal logs in JSON mode to keep stdout clean for piping
        if (program.opts().json || cmdName === "mcp") {
            // Suppress zca-js stdout logs: JSON mode needs clean output, MCP uses stdout as transport
            process.env.ZALO_JSON_MODE = "1";
        } else if (cmdName !== "oa") {
            // OA commands use official Zalo API — no disclaimer needed
            warning(DISCLAIMER);
            console.log();
        }
        // Auto-login before any command that needs it (skip for login/account/oa commands)
        const skipAutoLogin = ["login", "account", "help", "version", "oa", "mcp"].includes(cmdName);
        if (!skipAutoLogin) {
            await autoLogin(program.opts().json);
        }
    });

// Register all command groups
registerLoginCommands(program);
registerMsgCommands(program);
registerFriendCommands(program);
registerGroupCommands(program);
registerConvCommands(program);
registerAccountCommands(program);
registerProfileCommands(program);
registerPollCommands(program);
registerReminderCommands(program);
registerAutoReplyCommands(program);
registerQuickMsgCommands(program);
registerLabelCommands(program);
registerCatalogCommands(program);
registerListenCommand(program);
registerOACommands(program);
registerMCPCommands(program);

program.parse();
